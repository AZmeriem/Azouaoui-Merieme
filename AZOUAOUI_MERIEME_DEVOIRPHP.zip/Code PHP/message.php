<?php

$lab['nom'] = array(
    'EN' => 'Last Name',
    'FR' => 'Nom'
);
$lab['prenom'] = array(
    'EN' => 'First Name',
    'FR' => 'Prenom'
);
$lab['photo'] = array(
    'EN' => 'Picture',
    'FR' => 'Photo'
);
$lab['emailPersonnel'] = array(
     'FR'=> 'E-mail pers',
    'EN' => 'E-mail'
);
$lab['emailProfessionnel'] = array(
     'FR'=> 'E-mail prof',
    'EN' => 'Professional e-mail'
);
$lab['adresse'] = array(
    'EN' => 'Location',
    'FR' => 'Adresse'
);
$lab['telephone1'] = array(
    'EN' => 'Phone 1',
    'FR' => 'Telephone1'
);
$lab['telephone2'] = array(
    'EN' => 'Phone 2',
    'FR' => 'Telephone2'
);
$lab['genre'] = array(
    'EN' => 'Gender',
    'FR' => 'Genre'
);

$messages['required_field'] = array(
    'EN' => 'The field {1} is required',
    'FR' => 'Le champ {1} est obligatoire'
);





?>