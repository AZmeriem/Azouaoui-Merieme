<?php 
const  LANG = 'FR';
?>